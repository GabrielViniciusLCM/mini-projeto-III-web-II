package com.jeanlima.springrestapiapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestApiAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
