package com.jeanlima.springrestapiapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestApiAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestApiAppApplication.class, args);
	}

}
