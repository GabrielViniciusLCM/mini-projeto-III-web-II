package com.jeanlima.springrestapiapp.enums;

public enum StatusPedido {

    REALIZADO,
    CANCELADO;

}
