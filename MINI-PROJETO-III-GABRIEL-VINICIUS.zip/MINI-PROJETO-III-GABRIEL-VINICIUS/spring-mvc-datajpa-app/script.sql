
-- inserindo cursos no banco
insert into curso (descricao) values ('BTI');
insert into curso (descricao) values ('Eng Comp');
insert into curso (descricao) values ('Eng Soft');
select * from curso;

insert into disciplina (descricao, codigo) values ('Desenvolvimento Web I', 'IMD0408');
insert into disciplina (descricao, codigo) values ('Desenvolvimento Web II', 'IMD0409');
insert into disciplina (descricao, codigo) values ('Desenvolvimento para Dispositivos Móveis', 'IMD0509');
select * from disciplina;